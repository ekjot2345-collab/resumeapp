// Resume Analyzer Pro - Application JavaScript (Fixed Version)

// Sample data embedded from the provided JSON
const appData = {
  "sample_resumes": [
    {
      "id": 1,
      "name": "Sarah Chen",
      "email": "sarah.chen@email.com",
      "title": "Senior Data Analyst",
      "location": "San Francisco, CA",
      "experience_years": 5,
      "skills": ["Python", "SQL", "Tableau", "Power BI", "Statistics", "Machine Learning", "Excel", "R"],
      "education": [{"degree": "M.S. Data Science", "university": "UC Berkeley", "year": "2019"}],
      "experience": [
        {
          "title": "Senior Data Analyst",
          "company": "TechCorp Inc.",
          "duration": "2021-Present",
          "achievements": [
            "Improved customer retention by 23% through predictive analytics",
            "Automated reporting processes saving 15 hours/week",
            "Built real-time dashboards serving 500+ stakeholders"
          ]
        }
      ],
      "ats_score": 87,
      "keyword_matches": 15,
      "missing_keywords": ["A/B Testing", "Apache Spark", "AWS"]
    },
    {
      "id": 2,
      "name": "Marcus Rodriguez",
      "email": "m.rodriguez@email.com",
      "title": "Software Engineer",
      "location": "Austin, TX",
      "experience_years": 3,
      "skills": ["JavaScript", "React", "Node.js", "Python", "MongoDB", "Docker", "Git", "AWS"],
      "education": [{"degree": "B.S. Computer Science", "university": "UT Austin", "year": "2020"}],
      "experience": [
        {
          "title": "Full Stack Developer",
          "company": "StartupXYZ",
          "duration": "2020-Present",
          "achievements": [
            "Developed microservices handling 1M+ requests daily",
            "Reduced application load time by 40%",
            "Led team of 4 junior developers"
          ]
        }
      ],
      "ats_score": 92,
      "keyword_matches": 18,
      "missing_keywords": ["Kubernetes", "TypeScript"]
    },
    {
      "id": 3,
      "name": "Emily Johnson",
      "email": "emily.j@email.com",
      "title": "Marketing Manager",
      "location": "New York, NY",
      "experience_years": 7,
      "skills": ["Digital Marketing", "SEO", "Google Analytics", "Social Media", "Content Strategy", "A/B Testing", "HubSpot"],
      "education": [{"degree": "MBA Marketing", "university": "NYU Stern", "year": "2017"}],
      "experience": [
        {
          "title": "Marketing Manager",
          "company": "Global Brands Co",
          "duration": "2019-Present",
          "achievements": [
            "Increased organic traffic by 150% in 18 months",
            "Managed $2M annual marketing budget",
            "Launched 15+ successful campaigns with 25% avg CTR improvement"
          ]
        }
      ],
      "ats_score": 78,
      "keyword_matches": 12,
      "missing_keywords": ["PPC", "Marketing Automation", "Salesforce"]
    }
  ],
  "reddit_career_insights": [
    {
      "category": "Data Science",
      "insights": [
        "Python and SQL are absolutely essential - mentioned in 95% of job postings",
        "Portfolio projects matter more than certifications according to hiring managers",
        "Average salary jump is $25k when moving from analyst to senior analyst role",
        "Remote work availability increased by 340% since 2020"
      ],
      "trending_skills": ["ChatGPT/LLM integration", "dbt", "Snowflake", "Apache Airflow"],
      "salary_trends": {
        "entry_level": "$70,000 - $95,000",
        "mid_level": "$95,000 - $130,000",
        "senior_level": "$130,000 - $180,000"
      }
    },
    {
      "category": "Software Engineering",
      "insights": [
        "TypeScript adoption growing rapidly - now in 67% of React job postings",
        "System design interviews are becoming standard even for mid-level roles",
        "Companies prioritizing full-stack skills over specialized frontend/backend",
        "AI/ML integration becoming expected skill for senior engineers"
      ],
      "trending_skills": ["TypeScript", "Next.js", "Kubernetes", "GraphQL", "Rust"],
      "salary_trends": {
        "entry_level": "$85,000 - $120,000",
        "mid_level": "$120,000 - $160,000",
        "senior_level": "$160,000 - $250,000"
      }
    }
  ],
  "linkedin_style_data": {
    "skill_demand": [
      {"skill": "Python", "demand_growth": "+45%", "avg_salary_premium": "$15k"},
      {"skill": "Cloud Computing", "demand_growth": "+67%", "avg_salary_premium": "$22k"},
      {"skill": "Machine Learning", "demand_growth": "+89%", "avg_salary_premium": "$28k"}
    ]
  }
};

// Global variables
let currentResume = null;
let charts = {};

// Initialize the application
document.addEventListener('DOMContentLoaded', function() {
  console.log('Initializing Resume Analyzer Pro...');
  initializeNavigation();
  initializeCharts();
  initializeResumeAnalyzer();
  initializeModals();
  initializeTabs();
  initializeActionCards();
  console.log('Application initialized successfully');
});

// Navigation functionality - FIXED
function initializeNavigation() {
  console.log('Setting up navigation...');
  const navItems = document.querySelectorAll('.nav-item');
  const sections = document.querySelectorAll('.content-section');

  navItems.forEach(item => {
    item.addEventListener('click', function(e) {
      e.preventDefault();
      e.stopPropagation();
      
      const targetSection = this.dataset.section;
      console.log('Navigating to section:', targetSection);
      
      // Update active nav item
      navItems.forEach(nav => nav.classList.remove('active'));
      this.classList.add('active');
      
      // Update active section
      sections.forEach(section => section.classList.remove('active'));
      const targetElement = document.getElementById(targetSection);
      if (targetElement) {
        targetElement.classList.add('active');
        console.log('Section activated:', targetSection);
      } else {
        console.error('Target section not found:', targetSection);
      }
    });
  });
}

// Initialize charts
function initializeCharts() {
  console.log('Initializing charts...');
  
  // Position Chart (Dashboard)
  const positionCtx = document.getElementById('positionChart');
  if (positionCtx) {
    try {
      charts.position = new Chart(positionCtx, {
        type: 'doughnut',
        data: {
          labels: ['Your Score', 'Average Score', 'Top Performers'],
          datasets: [{
            data: [87, 72, 95],
            backgroundColor: ['#1FB8CD', '#FFC185', '#B4413C'],
            borderWidth: 0
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend: {
              position: 'bottom'
            }
          }
        }
      });
      console.log('Position chart created successfully');
    } catch (error) {
      console.error('Error creating position chart:', error);
    }
  }

  // Salary Chart (Job Market)
  const salaryCtx = document.getElementById('salaryChart');
  if (salaryCtx) {
    try {
      charts.salary = new Chart(salaryCtx, {
        type: 'line',
        data: {
          labels: ['Entry Level', 'Mid Level', 'Senior Level', 'Principal'],
          datasets: [{
            label: 'Data Science',
            data: [82500, 112500, 155000, 200000],
            borderColor: '#1FB8CD',
            backgroundColor: 'rgba(31, 184, 205, 0.1)',
            fill: true,
            tension: 0.4
          }, {
            label: 'Software Engineering',
            data: [102500, 140000, 205000, 280000],
            borderColor: '#FFC185',
            backgroundColor: 'rgba(255, 193, 133, 0.1)',
            fill: true,
            tension: 0.4
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          scales: {
            y: {
              beginAtZero: false,
              ticks: {
                callback: function(value) {
                  return '$' + (value / 1000) + 'k';
                }
              }
            }
          },
          plugins: {
            legend: {
              position: 'top'
            }
          }
        }
      });
      console.log('Salary chart created successfully');
    } catch (error) {
      console.error('Error creating salary chart:', error);
    }
  }

  // Network Growth Chart
  const networkCtx = document.getElementById('networkChart');
  if (networkCtx) {
    try {
      charts.network = new Chart(networkCtx, {
        type: 'bar',
        data: {
          labels: ['Technology', 'Finance', 'Healthcare', 'Marketing'],
          datasets: [{
            label: 'Growth Rate (%)',
            data: [15.2, 8.7, 12.3, 6.8],
            backgroundColor: ['#1FB8CD', '#FFC185', '#B4413C', '#ECEBD5']
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          scales: {
            y: {
              beginAtZero: true,
              ticks: {
                callback: function(value) {
                  return value + '%';
                }
              }
            }
          },
          plugins: {
            legend: {
              display: false
            }
          }
        }
      });
      console.log('Network chart created successfully');
    } catch (error) {
      console.error('Error creating network chart:', error);
    }
  }
}

// Resume analyzer functionality - FIXED
function initializeResumeAnalyzer() {
  console.log('Setting up resume analyzer...');
  const sampleCards = document.querySelectorAll('.sample-card');
  const uploadBtn = document.querySelector('.upload-btn');

  sampleCards.forEach((card, index) => {
    card.addEventListener('click', function(e) {
      e.preventDefault();
      e.stopPropagation();
      
      const resumeIndex = parseInt(this.dataset.resume);
      console.log('Sample card clicked, analyzing resume:', resumeIndex);
      analyzeResume(resumeIndex);
    });
  });

  if (uploadBtn) {
    uploadBtn.addEventListener('click', function(e) {
      e.preventDefault();
      console.log('Upload button clicked, analyzing sample resume');
      // Simulate file upload and analyze the first sample resume
      analyzeResume(0);
    });
  }
}

// FIXED: Resume analysis function
function analyzeResume(resumeIndex) {
  console.log('Analyzing resume at index:', resumeIndex);
  
  if (!appData.sample_resumes[resumeIndex]) {
    console.error('Resume not found at index:', resumeIndex);
    return;
  }
  
  const resume = appData.sample_resumes[resumeIndex];
  currentResume = resume;
  
  console.log('Resume data:', resume);
  
  // Show analysis results
  const resultsContainer = document.getElementById('analysisResults');
  if (resultsContainer) {
    resultsContainer.classList.remove('hidden');
    console.log('Analysis results container shown');
    
    // Update ATS Score with animation
    setTimeout(() => {
      animateScore('atsScore', resume.ats_score);
    }, 500);
    
    // Update progress bars with delay for visual effect
    setTimeout(() => {
      updateProgressBar('format', 85);
      updateProgressBar('keywords', Math.min((resume.keyword_matches / 20) * 100, 100));
      updateProgressBar('content', 90);
    }, 800);
    
    // Update keyword stats
    setTimeout(() => {
      const matchedElement = document.getElementById('matchedKeywords');
      const missingElement = document.getElementById('missingKeywords');
      
      if (matchedElement) matchedElement.textContent = resume.keyword_matches;
      if (missingElement) missingElement.textContent = resume.missing_keywords.length;
      
      console.log('Keyword stats updated');
    }, 1000);
    
    // Update keyword tags
    setTimeout(() => {
      updateKeywordTags(resume);
    }, 1200);
    
    // Update suggestions
    setTimeout(() => {
      updateSuggestions(resume);
    }, 1500);
    
    // Scroll to results
    setTimeout(() => {
      resultsContainer.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }, 1800);
    
  } else {
    console.error('Analysis results container not found');
  }
}

function animateScore(elementId, targetScore) {
  const element = document.getElementById(elementId);
  if (!element) {
    console.error('Score element not found:', elementId);
    return;
  }
  
  console.log('Animating score to:', targetScore);
  
  let currentScore = 0;
  const increment = targetScore / 30;
  
  const animation = setInterval(() => {
    currentScore += increment;
    if (currentScore >= targetScore) {
      currentScore = targetScore;
      clearInterval(animation);
    }
    element.textContent = Math.round(currentScore);
  }, 50);
}

function updateProgressBar(section, percentage) {
  const progressBar = document.querySelector(`[data-section="${section}"]`);
  if (progressBar) {
    console.log(`Updating progress bar ${section} to ${percentage}%`);
    setTimeout(() => {
      progressBar.style.width = percentage + '%';
    }, 100);
  } else {
    console.error('Progress bar not found for section:', section);
  }
}

function updateKeywordTags(resume) {
  const container = document.getElementById('keywordsTags');
  if (!container) {
    console.error('Keywords tags container not found');
    return;
  }
  
  console.log('Updating keyword tags');
  container.innerHTML = '';
  
  // Add matched keywords (limit to actual matched count)
  const matchedSkills = resume.skills.slice(0, resume.keyword_matches);
  matchedSkills.forEach(skill => {
    const tag = document.createElement('span');
    tag.className = 'keyword-tag matched';
    tag.textContent = skill;
    container.appendChild(tag);
  });
  
  // Add missing keywords
  resume.missing_keywords.forEach(keyword => {
    const tag = document.createElement('span');
    tag.className = 'keyword-tag missing';
    tag.textContent = keyword;
    container.appendChild(tag);
  });
  
  console.log('Keyword tags updated successfully');
}

function updateSuggestions(resume) {
  const container = document.getElementById('suggestionsList');
  if (!container) {
    console.error('Suggestions container not found');
    return;
  }
  
  console.log('Updating suggestions');
  
  const suggestions = [
    `Add missing keywords: ${resume.missing_keywords.join(', ')}`,
    'Quantify achievements with specific numbers and percentages',
    'Include industry-specific terminology relevant to your field',
    'Optimize section headers to match common ATS expectations'
  ];
  
  container.innerHTML = '';
  
  suggestions.forEach(suggestion => {
    const item = document.createElement('div');
    item.className = 'suggestion-item';
    item.innerHTML = `
      <div class="suggestion-icon">
        <i class="fas fa-lightbulb"></i>
      </div>
      <div class="suggestion-text">${suggestion}</div>
    `;
    container.appendChild(item);
  });
  
  console.log('Suggestions updated successfully');
}

// Modal functionality
function initializeModals() {
  const modal = document.getElementById('resumeModal');
  const closeBtn = document.querySelector('.modal-close');
  
  if (closeBtn) {
    closeBtn.addEventListener('click', function() {
      modal.classList.add('hidden');
    });
  }
  
  // Close modal when clicking outside
  if (modal) {
    modal.addEventListener('click', function(e) {
      if (e.target === modal) {
        modal.classList.add('hidden');
      }
    });
  }
}

// Tab functionality - FIXED
function initializeTabs() {
  console.log('Setting up tabs...');
  const tabButtons = document.querySelectorAll('.tab-btn');
  const tabContents = document.querySelectorAll('.tab-content');
  
  tabButtons.forEach(button => {
    button.addEventListener('click', function(e) {
      e.preventDefault();
      const targetTab = this.dataset.tab;
      console.log('Tab clicked:', targetTab);
      
      // Update active tab button
      tabButtons.forEach(btn => btn.classList.remove('active'));
      this.classList.add('active');
      
      // Update active tab content
      tabContents.forEach(content => content.classList.remove('active'));
      const targetContent = document.getElementById(targetTab);
      if (targetContent) {
        targetContent.classList.add('active');
        console.log('Tab content activated:', targetTab);
      }
    });
  });
}

// Action cards functionality - FIXED
function initializeActionCards() {
  console.log('Setting up action cards...');
  const actionCards = document.querySelectorAll('.action-card');
  
  actionCards.forEach(card => {
    card.addEventListener('click', function(e) {
      e.preventDefault();
      e.stopPropagation();
      
      const action = this.dataset.action;
      console.log('Action card clicked:', action);
      
      if (action === 'analyze') {
        // Switch to analyze section
        const analyzeNavItem = document.querySelector('[data-section="analyze"]');
        if (analyzeNavItem) {
          analyzeNavItem.click();
        }
      } else if (action === 'market') {
        // Switch to market section
        const marketNavItem = document.querySelector('[data-section="market"]');
        if (marketNavItem) {
          marketNavItem.click();
        }
      }
    });
  });
}

// Add some interactive enhancements
document.addEventListener('DOMContentLoaded', function() {
  // Add smooth scrolling for internal navigation
  const internalLinks = document.querySelectorAll('a[href^="#"]');
  
  internalLinks.forEach(link => {
    link.addEventListener('click', function(e) {
      e.preventDefault();
      const target = document.querySelector(this.getAttribute('href'));
      if (target) {
        target.scrollIntoView({
          behavior: 'smooth',
          block: 'start'
        });
      }
    });
  });
  
  // Add keyboard navigation support
  document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
      const modal = document.querySelector('.modal:not(.hidden)');
      if (modal) {
        modal.classList.add('hidden');
      }
    }
  });
});

// Utility functions for data formatting
function formatSalary(amount) {
  return '$' + amount.toLocaleString();
}

function formatPercentage(value) {
  return value >= 0 ? `+${value}%` : `${value}%`;
}

function formatNumber(num) {
  if (num >= 1000000) {
    return (num / 1000000).toFixed(1) + 'M';
  } else if (num >= 1000) {
    return (num / 1000).toFixed(1) + 'k';
  }
  return num.toString();
}